#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Particula.h"
#include "Jugador.h"
#include <qdebug.h>
#include <QLabel>
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) //La interfaz diseñada en Qt Designer
{
    ui->setupUi(this); //This hace referencia a la clase MainWindow, configura la interfaz de usuario definida en el Qt designer
    //bool clic = true; //No hay necesidad de declararla de nuevo
    QGraphicsScene *scene = new QGraphicsScene(this); // se debe crear una escena para manejar elementos gráficos
    scene->setSceneRect(0, 0, 800, 500);
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setFixedSize(800 + 2 * ui->graphicsView->frameWidth(), 500 + 2 * ui->graphicsView->frameWidth());//manejar la relación de aspecto
    tiempoTrans = 0;

    //QPixmap backgroundImage(":/background.jpg");
    //QGraphicsPixmapItem *background = scene->addPixmap(backgroundImage);


    /*QTimer *bgTimer = new QTimer(this);
    connect(bgTimer, &QTimer::timeout, [=]() {
        
        QPointF newPos = background->pos() - QPointF(1, 0); // Se ajustan las coordenadas del bg
        background->setPos(newPos);
        qDebug() << newPos << " " << scene->width() << background->pos().x() + background->pixmap().width();

        
        if (background->pos().x() + background->pixmap().width() <= scene->width())
            background->setPos(QPointF(0, 0)); // Volver al principio de la imagen
    });
    bgTimer->start(50); */


    Particula *bola = new Particula(ui->graphicsView, 50, 100,100,45*(3.1415/180));
    scene->addItem(bola);
    bola->setPos(100,100);

    Jugador *jug1 = new Jugador(ui->graphicsView);
    scene -> addItem(jug1);
    jug1->setPos(200,200);
    qDebug() << ui->graphicsView->size()<<" "<<scene->sceneRect();


    timer = new QTimer;
    //connect(timer,SIGNAL(timeout()),this,SLOT(hmov(*bola)));
    connect(timer, &QTimer::timeout, [=]() {
        hmov(bola);
        if(bola->collidesWithItem(jug1)){
            qDebug()<< "Colision detectada";
        }
    });
    timer->stop();

    /*La función connect debe ser ajustada para conectar a la señal con el slot. La función hmov toma un puntero al objeto Particula como argumento
     * y no se puede conectar directamente al timeout del timer. Se puede utilizar una función lambda o una función auxiliar:
     *
     * private slots:
    void onTimeout(); // Declaration of the helper function

private:
    void connectTimer(); // Se crea una función para conectar el timer en el .h

Dentro del mainwindow.cpp:


void MainWindow::onTimeout() {
    hmov(bola);
}
Se define la función:
void MainWindow::connectTimer() {
    connect(timer, &QTimer::timeout, this, &MainWindow::onTimeout);

La función "helper" o auxiliar no acepta parámetros sino que simplemente llama al slot hmov. Luego, hay una función connectTimer que es responsable de conectar la
señal de timeout.

     */


}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{
    if (clic){
        ui->pushButton->setText("Hizo click");
        clic = false;
    }
    else{
        ui->pushButton->setText("Haga clic");
        clic = true;
    }
    if (timer->isActive()) timer->stop();
    else timer->start(10);

}

void MainWindow::hmov(Particula *bola)
{
    bola->movParabolico(&this->tiempoTrans);
    tiempoTrans+=0.01;
}


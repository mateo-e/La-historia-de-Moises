#include "Jugador.h"
#include <QGraphicsScene>
#include <QLabel>
#include <QPixmap>
#include <QKeyEvent>
#include <QDebug>

//Definir el jugador y la imgen
Jugador::Jugador(QGraphicsView *view,QGraphicsItem *im):QGraphicsPixmapItem(im)
{
    //setPixmap(QPixmap(":/sprites.png"));
    x=200;
    y=200;
    setFlag(QGraphicsItem::ItemIsFocusable); //Inicialización opcional para decir que tiene el foco para eventos del teclado
    //sceneRect = scene->sceneRect();
    //qDebug() << scene->sceneRect();
    viewRect = view->size();
    QRectF sceneRect = view->sceneRect();
    qDebug() << viewRect << " "<< sceneRect << " "<<view->size().width();
    spriteSheet.load(":/sprites.png");

    QPixmap sprite = spriteSheet.copy(spriteX, spriteY, spriteWidth, spriteHeight);
    setPixmap(sprite);

}



void Jugador::keyPressEvent(QKeyEvent *event)
{
    //Manejo del evento de tecla
    switch(event->key()) {
    case Qt::Key_A:
        //qDebug() << "Tecla: " << event->key();
        moveBy(-5, 0);
        setSprite(60);
        break;
    case Qt::Key_D:
        //qDebug() << "Tecla: " << event->key();
        moveBy(5, 0);
        setSprite(120);
        break;
    case Qt::Key_W:
        //qDebug() << "Tecla: " << event->key();
        moveBy(0, -5);
        break;
    case Qt::Key_S:
        //qDebug() << "Tecla: " << event->key();
        moveBy(0, 5);
        break;
    default:
        QGraphicsItem::keyPressEvent(event);
    }
}

void Jugador::moveBy(int dx, int dy)
{
    x += dx;
    y += dy;
    qDebug() << x << " "<<y;
    //qDebug() << "Tecla: " << x << " " <<sceneRect.right()<<" "<<sceneRect.left();
    if (x>viewRect.width()-50||x<0){
        x-=dx;
    }
    setPos(x, y);
}

void Jugador::setSprite(int dir)
{
    spriteX = 60*cont;
    spriteY = dir;
    QPixmap sprite = spriteSheet.copy(spriteX, spriteY, spriteWidth, spriteHeight);
    setPixmap(sprite);
    cont++;
    if(cont==7){cont=0;}
}

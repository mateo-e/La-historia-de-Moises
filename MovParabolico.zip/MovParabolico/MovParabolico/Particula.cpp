#include "Particula.h"
#include <QPainter>
#include <QKeyEvent>
#include <QDebug>
#include <QTimer>
#include <QObject>
#include <cmath>

Particula::Particula(QGraphicsView *view, float velIn,  qreal xIn, qreal yIn, float theta,QGraphicsItem *parent)
    : QGraphicsItem(parent), velIn(velIn), theta(theta), xIn(xIn), yIn(yIn)
{
    setFlag(QGraphicsItem::ItemIsFocusable); //Inicialización opcional para decir que tiene el foco para eventos del teclado
    viewRect = view ->size();
    dir=1;

}

QRectF Particula::boundingRect() const
{
    return QRectF(-5, -5, 10, 10); // Xoordenadas iniciales del rect (sobre el origen del punto), unidades a la derecha y unidades abajo
}

void Particula::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::red);
    painter->drawEllipse(-5, -5, 10, 10); // Adjust as needed
}

void Particula::keyPressEvent(QKeyEvent *event)
{
    //Manejo del evento de tecla
    switch(event->key()) {
    case Qt::Key_Up:
        moveBy(0, -5);
        break;
    case Qt::Key_Down:
        moveBy(0, 5);
        break;
    case Qt::Key_A:
        qDebug() << "Tecla: " << event->key();
        moveBy(-5, 0);
        break;
    case Qt::Key_D:
        qDebug() << "Tecla: " << event->key();
        moveBy(5, 0);
        break;
    case Qt::Key_W:
        qDebug() << "Tecla: " << event->key();
        moveBy(0, -5);
        break;
    case Qt::Key_S:
        qDebug() << "Tecla: " << event->key();
        moveBy(0, 5);
        break;
    default:
        QGraphicsItem::keyPressEvent(event);
    }
}

void Particula::moveBy(int dx, int dy)
{
    posX += dx;
    posY += dy;
    setPos(posX, posY);
}

void Particula::movParabolico(float *dt)
{
    posX = xIn + (velIn*cos(theta) * *dt)*dir;
    posY = yIn - (velIn *sin(theta) * *dt) + (0.5*9.8 * *dt * *dt);
    if(posX>viewRect.width() - 5 || posX<0){
        velIn = 0.8*velIn;
        dir = -1*dir;
        xIn = posX + 10*dir;
        *dt = 0;
        yIn = posY;
        theta= 0;// -atan(velIn*cos(theta)/velIn*sin(theta) * *dt);

    }
    if(posY>viewRect.height()){
        theta = -atan((velIn*sin(theta)-9.8 * *dt)/velIn*cos(theta));
        velIn = 0.8 * sqrt(pow(velIn*sin(theta)-9.8 * *dt,2)+pow(velIn*cos(theta),2));
        *dt = 0;
        posY = posY-5;
        yIn = posY;
        xIn = posX;
    }


    setPos(posX,posY);
}
